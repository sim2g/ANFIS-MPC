# UDPExample
Example UDP Receiver and Transmitter project in Unity(2018.4.3f.1).I created this project to communicate my simulation&game projects with Matlab&Simulink(tested with 2018a) for testing automatic control algorithms.You can get Unity project from /UDPExample folder. You can also get example Simulink model that contains UDP Transmitter and Receiver from /Simulink folder.

You can read the tutorial about it from : https://medium.com/@cihaddogan/udp-communication-between-unity-and-matlab-simulink-d4a62921936d
